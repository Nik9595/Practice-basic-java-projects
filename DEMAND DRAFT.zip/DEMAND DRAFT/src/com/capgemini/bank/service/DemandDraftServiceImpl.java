package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAOImpl;
import com.capgemini.bank.exception.CustomerException;

public class DemandDraftServiceImpl implements IDemandDraftService {
	
	DemandDraftDAOImpl dddao = new DemandDraftDAOImpl();

	@Override
	public int addDemandDraftDetails(DemandDraft dd) throws CustomerException {
		// TODO Auto-generated method stub
		return dddao.addDemandDraftDetails(dd);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transId) throws CustomerException {
		// TODO Auto-generated method stub
		return dddao.getDemandDraftDetails(transId);
	}

	@Override
	public boolean isValidDemandDraftDetails(DemandDraft dd) throws CustomerException {
		// TODO Auto-generated method stub
		
		if(!dd.getPhoneNumber().matches("[0-9]{10}"))
		{
			throw new CustomerException("Phone number entered is invalid",null);
		}
			
		if(!dd.getCustomerName().matches("[A-Z][a-z]{3,}"))
		{
			throw new CustomerException("Customer name should start with capital letter with min 4 letters",null);
		}
		return true;
	}

}
