package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.CustomerException;

public interface IDemandDraftService {
	

	public int addDemandDraftDetails(DemandDraft dd)throws CustomerException;
	public DemandDraft getDemandDraftDetails(int transId)throws CustomerException;
	public boolean isValidDemandDraftDetails(DemandDraft dd)throws CustomerException;

}
