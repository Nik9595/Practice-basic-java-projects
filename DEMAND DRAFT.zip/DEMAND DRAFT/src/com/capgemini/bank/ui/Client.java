package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAOImpl;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.CustomerException;
import com.capgemini.bank.service.DemandDraftServiceImpl;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	public static void main(String[] args) throws CustomerException{
		
		IDemandDraftService idds = new DemandDraftServiceImpl();
		IDemandDraftDAO iddd = new DemandDraftDAOImpl();
		DemandDraftDAOImpl ddd = new DemandDraftDAOImpl();
		
		DemandDraft ddraft = new DemandDraft();
		
		double commission;
		
		Scanner sc = new Scanner(System.in);
		
		do
		{
			System.out.println(" ");
			System.out.println("    Welcome to Banking Applications    ");
			System.out.println(" Select your Choice");
			System.out.println(" 1.    Enter Demand Draft Details ");
			System.out.println(" 2.    Print Demand Draft Details ");
			System.out.println(" 3.    Exit ");
			System.out.println(" ");
			
			int choice = sc.nextInt();
			
			
			switch(choice)
			{
			
			case 1:
				System.out.println(" Enter Customer's Name  ");
				ddraft.setCustomerName(sc.next());
				
				System.out.println(" Enter : In Favour Of  ");
				ddraft.setInFavourOf(sc.next());
				
				System.out.println(" Enter Customer's Phone Number  ");
				ddraft.setPhoneNumber(sc.next());
				
				System.out.println(" Enter DD Amount  ");
				double ddAmount=sc.nextDouble();
				
				ddraft.setDdAmount(ddAmount);
				
				
				if(ddAmount <= 500){
					commission=10;
					ddraft.setDdCommission(commission);}
				
				else if(ddAmount>=5001 && ddAmount<=10000){
					commission=41;
					ddraft.setDdCommission(commission);
				}
				else if(ddAmount>=10001 && ddAmount<=100000){
					commission=51;
					ddraft.setDdCommission(commission);
				}
				else if(ddAmount>=100001 && ddAmount<=500000){
					commission=306;
					ddraft.setDdCommission(commission);}
				
				
				System.out.println(" Enter the Description of your DD");
				ddraft.setDdDescription(sc.next());
				
				try{
					if(idds.isValidDemandDraftDetails(ddraft))
					{
						iddd.addDemandDraftDetails(ddraft);
						System.out.println(" \n");
						System.out.println("Your Demand Draft request has been registered successfully");
						System.out.println(" \n");
						System.out.println("Thank you  "+ddraft.getCustomerName()+
								" ,we will contact you shortly ");
						System.out.println(" \n");
						
						
			}
				}
				catch(CustomerException e)
				{
					e.printStackTrace();
					System.out.println("Please try Again");
				}
				break;
				
			case 2:
				System.out.println(" ");
				System.out.println("Enter Transaction Id to get Customers Details");
				iddd = new DemandDraftDAOImpl();
				int transId=sc.nextInt();
				ddraft=iddd.getDemandDraftDetails(transId);
				
				System.out.println(" \n");
				System.out.println("Name of the bank: XYZ");
				System.out.println("Customer Name : "+ddraft.getCustomerName());
				
				System.out.println("Phone Number : "+ddraft.getPhoneNumber());
				
				System.out.println("Your Transaction date : "+ddraft.getDateOfTransaction());
				
				System.out.println("DD Amount = : "+ddraft.getDdAmount());
				
				System.out.println("DD Commission : "+ddraft.getDdCommission());
				
				double total = ddraft.getDdAmount() + ddraft.getDdCommission();
				
				System.out.println("Total Amount : "+total);
				
				System.out.println("DD Description : "+ddraft.getDdDescription());
				
				break;
				
			case 3:
				System.out.println(" \n");
				System.out.println("Thank you and have safe services with Banking Applications ");
			
				System.exit(0);
				break;
			
			default: System.out.println("Enter a valid Choice");
		
			
			}
		}
	while(true);	
		
	}

}







