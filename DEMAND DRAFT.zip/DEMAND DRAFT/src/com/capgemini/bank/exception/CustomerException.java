package com.capgemini.bank.exception;

	
	public class CustomerException extends Exception{
		
		public CustomerException()
		{
			super();
		}
		public CustomerException (String message,Throwable cause)
		{
			super(message,cause);
		}

}
