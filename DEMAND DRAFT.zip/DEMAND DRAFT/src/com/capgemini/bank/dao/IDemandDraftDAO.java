package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.CustomerException;

public interface IDemandDraftDAO {
	
	public int addDemandDraftDetails(DemandDraft dd)throws CustomerException;
	public DemandDraft getDemandDraftDetails(int transId)throws CustomerException;
	
	

}
