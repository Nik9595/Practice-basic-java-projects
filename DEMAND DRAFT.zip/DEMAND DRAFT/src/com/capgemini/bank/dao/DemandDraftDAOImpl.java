package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;

import org.apache.log4j.Logger;

import com.capgemini.bank.DBUtils.DBUtils;
import com.capgemini.bank.DBUtils.Log4jHTMLLayout;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.CustomerException;

public class DemandDraftDAOImpl implements IDemandDraftDAO {

	
private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	private Connection dbConnection;
	{
		try{
			dbConnection =DBUtils.getConnection();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();	
		}
	}
	
	
	private int generateNextTransactionId() throws SQLException {
		int transId = 0;

		String selectQuery = "select transaction_id_seq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		transId = result.getInt(1);
		return transId;
	}

	
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft dd) throws CustomerException {
		// TODO Auto-generated method stub
		
		String insertQuery ="insert into demand_draft values(?,?,?,?,sysdate,?,?,?)";
		
		try{
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextTransactionId());
			insertStatement.setString(2,dd.getCustomerName());
			insertStatement.setString(3, dd.getInFavourOf());
			insertStatement.setString(4, dd.getPhoneNumber());
		
			insertStatement.setDouble(5, dd.getDdAmount());
			insertStatement.setDouble(6, dd.getDdCommission());
			insertStatement.setString(7, dd.getDdDescription());
			
			
			int rows = insertStatement.executeUpdate();
			if(rows>0){
				System.out.println(" \n");
				System.out.println("New Customer Added..");
				System.out.println(" \n");
				log.info("New Customer is Added");
				return 1;
			}
			else 
				return 0;		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return 0;
		}	
	}
			

	@Override
	public DemandDraft getDemandDraftDetails(int transId) throws CustomerException {
		// TODO Auto-generated method stub
		
		String selectQuery = "select * from Demand_draft where transaction_Id = ?";
		

		try{
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
			selectStatement.setInt(1, transId);
			
			ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
				int transactionId = result.getInt(1);
				String customerName = result.getString(2);
				String inFavourOf =result.getString(3);
				String phoneNumber =result.getString(4);
				Date dateOfTransaction=result.getDate(5);
				double ddAmount=result.getDouble(6);
				double ddCommission=result.getDouble(7);
				String ddDescription=result.getString(8);
				
				DemandDraft dmd =new DemandDraft();
				
				dmd.setTransactionId(transactionId);
				dmd.setCustomerName(customerName);
				dmd.setInFavourOf(inFavourOf);
				dmd.setPhoneNumber(phoneNumber);
				dmd.setDateOfTransaction(dateOfTransaction);
				dmd.setDdAmount(ddAmount);
				dmd.setDdCommission(ddCommission);
				dmd.setDdDescription(ddDescription);
				
				return dmd;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustomerException("Customer not found",e);
		}
		return null;
			
	}

}





