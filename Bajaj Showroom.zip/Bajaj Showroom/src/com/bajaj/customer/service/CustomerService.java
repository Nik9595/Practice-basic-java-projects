package com.bajaj.customer.service;

import com.bajaj.customer.bean.CustomerBean;
import com.bajaj.customer.exception.CustomerException;

public interface CustomerService {

	public int addDetails(CustomerBean cust) throws CustomerException;
	public CustomerBean getDetails(int custId) throws CustomerException;
    public boolean isValidDetails(CustomerBean cust)throws CustomerException;

	public CustomerBean deleteDetails(int custId2)throws CustomerException;
	
}
