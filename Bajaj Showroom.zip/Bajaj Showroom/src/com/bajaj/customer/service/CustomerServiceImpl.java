package com.bajaj.customer.service;

import com.bajaj.customer.bean.CustomerBean;
import com.bajaj.customer.dao.CustomerDAO;
import com.bajaj.customer.dao.CustomerDAOImpl;
import com.bajaj.customer.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService {
	
	CustomerDAO cdao=new CustomerDAOImpl();

	@Override
	public int addDetails(CustomerBean cust) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.addDetails(cust);
	}

	@Override
	public CustomerBean getDetails(int custId) throws CustomerException {
		// TODO Auto-generated method stub
		return cdao.getDetails(custId);
	}

	@Override
	public boolean isValidDetails(CustomerBean cust) throws CustomerException {
		// TODO Auto-generated method stub
		
		if(!cust.getPhoneNo().matches("[0-9]{10}"))
		{
			throw new CustomerException("Phone number entered must be correct ",null);	
		}
		return true;
	}

}
