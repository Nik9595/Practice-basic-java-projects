package com.bajaj.customer.ui;

import java.util.Scanner;

import com.bajaj.customer.bean.CustomerBean;
import com.bajaj.customer.dao.CustomerDAO;
import com.bajaj.customer.dao.CustomerDAOImpl;
import com.bajaj.customer.exception.CustomerException;
import com.bajaj.customer.service.CustomerService;
import com.bajaj.customer.service.CustomerServiceImpl;

public class CustomerMain {

	public static void main(String[] args) throws CustomerException{
		
		CustomerService cs=new CustomerServiceImpl();
		CustomerDAO daoRef=new CustomerDAOImpl();
		CustomerDAOImpl cdi=new CustomerDAOImpl();
		
		CustomerBean cub = new CustomerBean();
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("<||>  ------   Welcome to BAJAJ Showroom    ------   <||> ");
			System.out.println(" ");
			System.out.println("Select your choice");
			System.out.println(" 1.       Enter Customer Details ");
			System.out.println(" 2.       View Customer Details by entering customer Id");
			System.out.println(" 3.       Exit ");
			System.out.println(" ");
			
			int choice = sc.nextInt();
			
			switch (choice)
			{
			case 1:
				System.out.println("Enter customer's name ");
				cub.setCustomerName(sc.next());
				
				System.out.println("Enter Customer's age ");
				cub.setAge(sc.next());
				
				System.out.println("Enter customer's phone number");
				cub.setPhoneNo(sc.next());
				
				System.out.println("Enter customer's requirement");
				cub.setRequirement(sc.next());
				
				try{
					if(cs.isValidDetails(cub))
					{
						daoRef.addDetails(cub);
						System.out.println("Thank you  "+cub.getCustomerName()+
								" ,we will contact you shortly ");
						
						
			}
				}
				catch(CustomerException e)
				{
					e.printStackTrace();
					System.out.println("Please try Again");
				}
				break;
				
			case 2:
				System.out.println("Enter customer id to find details");
				daoRef =new CustomerDAOImpl();
				int custId =sc.nextInt();
				cub=daoRef.getDetails(custId);
				
				System.out.println("Customer Id : "+cub.getCustomerId()+
				"\n Customer Name : "+cub.getCustomerName()+
				"\n Customers phone Number : "+cub.getPhoneNo()+
				"\n Customers requirement : "+cub.getRequirement());
				
				
			break;
			
			case 3:
				System.out.println("Thank you and Enjoy services with BAJAJ ");
				System.exit(0);
				
				break;
				
				default : 	System.out.println("Invalid Choice..Try Again..!!");
				
			}
		}
		while(true);
	}
}
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
				
			
			
			
		
		
		
		
		
		
		
		
		
		
		

