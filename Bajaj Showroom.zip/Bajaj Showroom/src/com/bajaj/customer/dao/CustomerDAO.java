package com.bajaj.customer.dao;

import com.bajaj.customer.bean.CustomerBean;
import com.bajaj.customer.exception.CustomerException;

public interface CustomerDAO {
	
	public int addDetails(CustomerBean cust) throws CustomerException;
	public CustomerBean getDetails(int custId) throws CustomerException;

}
