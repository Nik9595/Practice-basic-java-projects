package com.bajaj.customer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.bajaj.customer.Utils.DBUtils;
import com.bajaj.customer.Utils.Log4jHTMLLayout;
import com.bajaj.customer.bean.CustomerBean;
import com.bajaj.customer.exception.CustomerException;

public class CustomerDAOImpl implements CustomerDAO {
	
	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	private Connection dbConnection;
	{
		try{
			dbConnection =DBUtils.getConnection();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
			
		}
	}
	private int generateNextCustomerId() throws SQLException {
		int custId = 0;

		String selectQuery = "select customerID_seq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		custId = result.getInt(1);
		return custId;
	}

	
	

	@Override
	public int addDetails(CustomerBean cust) throws CustomerException {
		
		String insertQuery ="insert into customer values(?,?,?,?,?)";
		try{
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextCustomerId());
			insertStatement.setString(2,cust.getCustomerName() );
			insertStatement.setString(3,cust.getAge());
			insertStatement.setString(4,cust.getPhoneNo());
			insertStatement.setString(5,cust.getRequirement());
			
			int rows = insertStatement.executeUpdate();
			if(rows>0){
				System.out.println("New Customer Added..");
				log.info("New Customer is Added");
				return 1;
			}
			else 
				return 0;		
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return 0;
		}	
	}
			
			
			
	
	@Override
	public CustomerBean getDetails(int custId) throws CustomerException {
		
		String selectQuery = "select * from customer where customerId = ?";
	
		try{
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			//remember this while retrieving using customerId
			selectStatement.setInt(1, custId);
			
			ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
				int customerId = result.getInt(1);
				String customerName = result.getString(2);
				String age = result.getString(3);
				String phoneNo = result.getString(4);
				String Requirement = result.getString(5);
				
				//find by id ke time object create krna CustomerBean ka
				
				CustomerBean cb=new CustomerBean();
				
				cb.setCustomerId(customerId);
				cb.setCustomerName(customerName);
				cb.setAge(age);
				cb.setPhoneNo(phoneNo);
				cb.setRequirement(Requirement);
				
				return cb;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new CustomerException("Customer not found",e);
		}
		return null;
	}	
			}



		