SCHEMA:

CREATE Table Customer
(customerId Number Primary key, customerName VARCHAR2(20),age NUMBER(3), phoneNo VARCHAR2(10),
Requirement VARCHAR2(20));

CREATE SEQUENCE customerId_seq
START WITH 7000
increment by 1;