package com.capgemini.pizzaorder.service;

import com.capgemini.pizzaorder.bean.CustomerDetails;
import com.capgemini.pizzaorder.bean.PizzaDetails;
import com.capgemini.pizzaorder.exception.PizzaOrderException;

public interface IPizzaOrderService {
	public int placeOrder(CustomerDetails custD,PizzaDetails piD)throws PizzaOrderException;
	public int showDetails(PizzaDetails pizD)throws PizzaOrderException;
	
	public PizzaDetails displayOrder(int orderId)throws PizzaOrderException;
	public boolean isValidCustomerDetails(CustomerDetails cd)throws PizzaOrderException;


}
