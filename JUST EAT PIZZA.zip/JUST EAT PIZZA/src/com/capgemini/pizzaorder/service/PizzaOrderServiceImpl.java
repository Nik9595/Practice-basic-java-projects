package com.capgemini.pizzaorder.service;


import com.capgemini.pizzaorder.bean.CustomerDetails;
import com.capgemini.pizzaorder.bean.PizzaDetails;
import com.capgemini.pizzaorder.dao.IPizzaOrderDAO;
import com.capgemini.pizzaorder.dao.PizzaOrderDAOImpl;
import com.capgemini.pizzaorder.exception.PizzaOrderException;

public class PizzaOrderServiceImpl implements IPizzaOrderService {
	
	PizzaOrderDAOImpl pdi = new PizzaOrderDAOImpl();

	@Override
	public int placeOrder(CustomerDetails custD, PizzaDetails piD) throws PizzaOrderException {
		// TODO Auto-generated method stub
		return pdi.placeOrder(custD, piD);
	}

	@Override
	public PizzaDetails displayOrder(int orderId) throws PizzaOrderException {
		// TODO Auto-generated method stub
		return pdi.displayOrder(orderId);
	}

	@Override
	public boolean isValidCustomerDetails(CustomerDetails cd) throws PizzaOrderException {
		// TODO Auto-generated method stub
		

		if(!cd.getPhoneNumber().matches("[0-9]{10}"))
		{
			throw new PizzaOrderException("Phone number entered must be correct ",null);	
		}	
		if(!cd.getCustName().matches("[A-Z][a-z]{3,}"))
		{
			throw new PizzaOrderException("Customer name should start with capital letter with min 4 letters",null);
		}
		return true;
	}

	@Override
	public int showDetails(PizzaDetails pizD) throws PizzaOrderException {
		// TODO Auto-generated method stub
		return pdi.showDetails(pizD);
	}


}
