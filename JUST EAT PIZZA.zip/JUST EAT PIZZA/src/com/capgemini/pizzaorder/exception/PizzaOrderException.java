package com.capgemini.pizzaorder.exception;

	
public class PizzaOrderException extends Exception{
		
		public PizzaOrderException()
		{
			super();
		}
		public PizzaOrderException (String message,Throwable cause)
		{
			super(message,cause);
		}

}


