package com.capgemini.pizzaorder.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.pizzaorder.DBUtils.DBUtils;
import com.capgemini.pizzaorder.DBUtils.Log4jHTMLLayout;
import com.capgemini.pizzaorder.bean.CustomerDetails;
import com.capgemini.pizzaorder.bean.PizzaDetails;
import com.capgemini.pizzaorder.exception.PizzaOrderException;

public class PizzaOrderDAOImpl implements IPizzaOrderDAO {
	
private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
	
	private Connection dbConnection;
	{
		try{
			dbConnection =DBUtils.getConnection();
		}catch(ClassNotFoundException e){
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();	
		}
	}

	
	private int generateNextCustomerId() throws SQLException {
		int custId = 0;

		String selectQuery = "select customerSeq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		custId = result.getInt(1);
		return custId;
	}

	private int generateNextOrderId() throws SQLException {
		int orderId = 0;

		String selectQuery = "select pizzaSeq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		orderId = result.getInt(1);
		return orderId;
	}
	
	
	@Override
	public int placeOrder(CustomerDetails custD, PizzaDetails piD) throws PizzaOrderException 
	{
		
		String insertQuery = "insert into customer_details values(?,?,?,?)";
		
		try
		{
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
		
			insertStatement.setInt(1, generateNextCustomerId());
			insertStatement.setString(2, custD.getCustName());
			insertStatement.setString(3, custD.getCustAddress());
			insertStatement.setString(4, custD.getPhoneNumber());
			int rows = insertStatement.executeUpdate();
			
					
			
			
			if(rows>0){
				System.out.println(" \n");
				System.out.println("Customer Data Added respectively");
				System.out.println(" \n");
				log.info("Data Added Successfully");
				return 1;
			}
			else 
				return 0;	
					
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return 0;
		}	
		
		
}
		



	

	@Override
	public PizzaDetails displayOrder(int orderId) throws PizzaOrderException {
		
		String selectQuery = "select * from pizza_entry where orderId = ?";
		
		try{
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
			selectStatement.setInt(1, orderId);
			
			ResultSet result = selectStatement.executeQuery();
			
			while(result.next())
			{
				int orderId1 =result.getInt(1);
				int custId1=result.getInt(2);
				Date orderDate=result.getDate(3);
				int totalPrice=result.getInt(4);
				
				PizzaDetails pzd = new PizzaDetails();
				pzd.setOrderId(orderId1);
				pzd.setCustId(custId1);
				pzd.setOrderdate(orderDate);
				pzd.setTotalPrice(totalPrice);
				
				return pzd;	
			}		
			}
		catch(SQLException e)
		{
			e.printStackTrace();
			throw new PizzaOrderException("Customer's Pizza not found",e);
		}
		return null;
			
	}

	@Override
	public int showDetails(PizzaDetails pzz) throws PizzaOrderException {
		// TODO Auto-generated method stub
		
		String insertQuery1 = "insert into pizza_entry values(?,?,sysdate,?)";
		
		try
		{
		PreparedStatement insertStatement1 = dbConnection.prepareStatement(insertQuery1);
		
		insertStatement1.setInt(1, generateNextOrderId());
		insertStatement1.setInt(2, generateNextCustomerId());
		insertStatement1.setDouble(3,pzz.getTotalPrice());
		int rows1=insertStatement1.executeUpdate();
			

		if(rows1>0){
			System.out.println(" \n");
			System.out.println("Pizza Data Added respectively");
			System.out.println(" \n");
			log.info("Data Added Successfully");
			return 1;
		}
		else 
			return 0;	
		}
		
		catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return 0;
	}
	}
}





