package com.capgemini.pizzaorder.dao;

import com.capgemini.pizzaorder.bean.CustomerDetails;
import com.capgemini.pizzaorder.bean.PizzaDetails;
import com.capgemini.pizzaorder.exception.PizzaOrderException;

public interface IPizzaOrderDAO {
	
	public int placeOrder(CustomerDetails custD,PizzaDetails piD)throws PizzaOrderException;
	public int showDetails(PizzaDetails pizD)throws PizzaOrderException;
	public PizzaDetails displayOrder(int orderId)throws PizzaOrderException;
	

}
