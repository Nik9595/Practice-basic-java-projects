package com.capgemini.pizzaorder.ui;

import java.util.Scanner;

import com.capgemini.pizzaorder.bean.CustomerDetails;
import com.capgemini.pizzaorder.bean.PizzaDetails;
import com.capgemini.pizzaorder.dao.IPizzaOrderDAO;
import com.capgemini.pizzaorder.dao.PizzaOrderDAOImpl;
import com.capgemini.pizzaorder.exception.PizzaOrderException;
import com.capgemini.pizzaorder.service.IPizzaOrderService;
import com.capgemini.pizzaorder.service.PizzaOrderServiceImpl;

public class Client {

	public static void main(String[] args) throws PizzaOrderException {
		// TODO Auto-generated method stub
		IPizzaOrderService ipos = new PizzaOrderServiceImpl();
		IPizzaOrderDAO ipod=new PizzaOrderDAOImpl();
		
		PizzaOrderDAOImpl podi=new PizzaOrderDAOImpl();
		
		CustomerDetails cudt = new CustomerDetails();
		PizzaDetails pzdt= new PizzaDetails();
		
		Scanner sc = new Scanner(System.in);
		
		while (true) 
		{

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("                           Welcome to JustEatPizzas                    ");
			System.out.println("___________________________________________________________________\n");
			System.out.println("1.                              Place an order ");
			System.out.println("2.                              Display order");
			System.out.println("3.                                  Exit");
			System.out.println("________________________________________________________________");
			System.out.println("                             Select an option:");
			
			int choice = sc.nextInt();
			
			switch(choice)
			{
			
			case 1:
				double totalprice=0;
				System.out.println();
				System.out.println();
				System.out.println("     Enter your details");
				
				System.out.println("Enter the name of your customer");
				cudt.setCustName(sc.next());
				
				System.out.println("Enter your address");
				cudt.setCustAddress(sc.next());
				
				System.out.println("Enter your phone number");
				cudt.setPhoneNumber(sc.next());
				
				
				System.out.println("Enter the type of pizza topping needed");
				System.out.println("capsicum {30} , mushroom {50} , jalepeno {70} , paneer {85}");
				String topping = sc.next();
				
				
				if(topping.equals("capsicum"))
				{
					totalprice = 350+30 + (0.04*(380));
					pzdt.setTotalPrice(totalprice);
					
				}
				
				else if(topping.equals("mushroom"))
				{
					
					totalprice = 350+50 + (0.04*(400));
					pzdt.setTotalPrice(totalprice);
					
				}
				else if(topping.equals("jalepeno"))
				{
					
					totalprice = 350+70 + (0.04*(420));
					pzdt.setTotalPrice(totalprice);
					
				}
				
				else if(topping.equals("paneer"))
				{
					
					totalprice = 350+85 + (0.04*(435));
					pzdt.setTotalPrice(totalprice);
					
				}
				else
				{
					System.out.println("Enter correctly");
				}
				System.out.println("Your total price is "+totalprice);
				
				
				int orderId = ipod.placeOrder(cudt, pzdt);
				//System.out.println("Your order Id is " + orderId);
				
				System.out.println("Your Order date is "+pzdt.getOrderdate());
				break;
				
				
			case 2:
				
				System.out.println();
				
				System.out.println("Enter your order Id to get your details");
				ipod=new PizzaOrderDAOImpl();
				int custId = sc.nextInt();
				pzdt=ipod.displayOrder(custId);
				
				System.out.println("your orderId is " + ipod);
				System.out.println("Total price " +pzdt.getTotalPrice());
				System.out.println("Order Date  " + pzdt.getOrderId());
				
				break;
				
			case 3:
				System.out.println(" \n");
				System.out.println("Thank you and Enjoy services with JUSTEATPIZZA");
			
				System.exit(0);
				break;
			
			default: System.out.println("Enter a valid Choice");
		

			
			}	
			
			}
			}
		}

