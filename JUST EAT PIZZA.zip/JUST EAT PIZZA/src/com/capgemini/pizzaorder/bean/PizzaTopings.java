package com.capgemini.pizzaorder.bean;

public enum PizzaTopings {
	
	

}
