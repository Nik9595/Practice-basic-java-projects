package com.capgemini.pizzaorder.bean;

import java.util.Date;

public class PizzaDetails {
	private int orderId;
	private int custId;
	private Date orderdate;
	private double totalPrice;
	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public Date getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalprice) {
		this.totalPrice = totalprice;
	}
	
	
	
	
	

}
